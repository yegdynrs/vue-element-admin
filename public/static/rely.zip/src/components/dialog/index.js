import dialog from './index.vue'

const Dialog = {

  install: function(Vue) {
    Vue.component('Dialog', dialog)
  }

}
export default Dialog
