<template>
  <div class="range-box">
    <el-input
      v-model="startValue"
      :placeholder="startPlaceholder"
      clearable
      @change="valueChange($event,0)"
    />
    <span> {{ separator }} </span>
    <el-input
      v-model="endValue"
      :placeholder="endPlaceholder"
      clearable
      @change="valueChange($event,1)"
    />
  </div>
</template>
<script>
export default {
  name: 'NumberRange',
  model: {
    event: 'change'
  },
  props: {
    separator: {
      type: String,
      default: '-'
    },
    startPlaceholder: {
      type: String,
      default: '开始值'
    },
    endPlaceholder: {
      type: String,
      default: '结束值'
    },
    value: {
      type: Array,
      default: () => []
    },
    min: {
      type: Number
    },
    max: {
      type: Number
    }
  },
  data() {
    return {
      startValue: this.value[0] || null,
      endValue: this.value[1] || null
    }
  },
  watch: {
    value(val) {
      this.startValue = val[0] || null
      this.endValue = val[1] || null
    }
  },
  methods: {
    clearData() {
      this.startValue = this.value[0] = null
      this.endValue = this.value[1] = null
    },
    valueChange(value, index) {
      value = this.recifyValue(value)
      var arrValue = [...this.value]
      arrValue[index] = value
      var isEmpty = this.$utils.isEmpty
      if (!isEmpty(arrValue[0]) && !isEmpty(arrValue[1]) && arrValue[0] >= arrValue[1]) {
        this.$notify.closeAll()
        this.$notify.info({
          title: '提示',
          message: `${this.startPlaceholder}不能大于或等于${this.endPlaceholder}`
        })
        index == 0 ? this.startValue = this.value[0] : this.endValue = this.value[1]
      } else {
        index == 0 ? this.startValue = value : this.endValue = value
        this.$emit('change', arrValue)
      }
    },
    recifyValue(value) {
      if (value == '') {
        value = null
      } else {
        value = Number(value)
        value = Number.isNaN(value) ? null : value
        value = this.min != null && value < this.min ? this.min : value
        value = this.max != null && value > this.max ? this.max : value
      }
      return value
    }
  }
}
</script>

<style lang="scss">
    .range-box{
        &>.el-input {
            width: 109px;
        .el-input__inner {
            padding-left: 5px;
        }
        }
    }
</style>
