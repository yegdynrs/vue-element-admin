<template>
  <div class="table_page">
    <div class="table-operation">
      <slot name="button_box" />
      <slot name="filtr_data" />
    </div>
    <el-table
      ref="table"
      v-loading="isload"
      :data="tableData"
      :row-key="rowKey"
      :tree-props="treeProps"
      :highlight-current-row="highlightCurrentRow"
      border
      :row-class-name="tableRowClassName"
      @sort-change="sortChange"
      @selection-change="selectionChange"
      @row-click="handleRowClick"
      @cell-dblclick="celldblclick"
    >
      <slot name="table_column" />
    </el-table>
    <slot name="handleoperation" />
    <el-pagination
      v-if="showPagination"
      :page-sizes="sizes"
      :layout="pageLayout"
      :total="totalPage"
      :current-page="currentPage"
      :page-size="pageSize"
      background
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </div>
</template>

<script>
export default {
  props: {
    tableData: {
      type: Array,
      default: () => []
    },
    currentPage: {
      type: Number,
      default: 1
    },
    totalPage: {
      type: Number,
      default: 1
    },
    isload: {
      type: Boolean,
      default: false
    },
    showPagination: {
      type: Boolean,
      default: false
    },
    pageSize: {
      type: Number,
      default: 10
    },
    highlightCurrentRow: {
      type: Boolean,
      default: false
    },
    rowClassName: {
      type: Function,
      default: () => {}
    },
    rowKey: {
      type: String,
      default: ''
    },
    treeProps: {
      type: Object,
      default: () => {
        return { children: '', hasChildren: '' }
      }
    },
    pageLayout: {
      type: String,
      default: 'sizes, prev, pager, next'
    }
  },
  data() {
    return {
      sizes: [5, 10, 20, 30]
    }
  },
  methods: {
    selectionChange(selection) {
      this.$emit('table-checked', selection)
    },
    currentChange(currentPage) {
      this.$emit('changPage', currentPage)
    },
    handleRowClick(row) {
      this.$emit('row-click', row)
    },
    handleSizeChange(val) {
      this.$emit('sizeChange', val)
    },
    // class
    tableRowClassName({ row, rowIndex }) {
      return this.rowClassName({ row, rowIndex })
    },
    celldblclick(row, column, cell, event) {
      const _this = this
      const value = cell.getElementsByClassName('cell')[0].innerText
      if (value) {
        this.$copyText(value).then(function(e) {
          _this.$notify.closeAll()
          _this.$notify.success({
            title: '提示',
            message: '复制成功'
          })
        }, function(e) {
          _this.$notify.closeAll()
          _this.$notify.error({
            title: '提示',
            message: '复制失败'
          })
        })
      }
    },
    clearSelection() {
      this.$refs.table.clearSelection()
    },
    sortChange(data) {
      this.$emit('sort-change', data)
    },
    clearSort() {
      this.$refs.table.clearSort()
    }
  }
}
</script>

<style lang="scss" scoped>
  .table-operation{
    overflow: hidden;
    .filtr-total{
      float: right;
      text-align: right;
      font-size: 14px;
      color: #333;
      padding:0 10px;
      line-height: 32px;
    }
    .button-box{
      float: left;
      margin-bottom: 10px;
    }
  }
	.table_page_number {
		margin-top: 35px;
		font-weight: normal;
		text-align: center;
	}
	::v-deep .el-table__empty-text{
		position: absolute;
		left: 50%;
		transform: translateX(-50%);
	}
	::v-deep .el-table__fixed::before, ::v-deep .el-table__fixed-right::before{
        bottom: -1px;
		z-index: -1;
    }
</style>
