<template>
  <div class="time-box">
    <el-date-picker v-model="startTime" :picker-options='optionsStart' type="date" placeholder="开始日期" @change="changeStartTime"
      format="yyyy-MM-dd" value-format="yyyy-MM-dd" :clearable='!islimitlength'>
    </el-date-picker>
    -
    <el-date-picker v-model="endTime" :picker-options='optionsEnd' type="date" placeholder="结束日期" @change="changeEndTime"
      format="yyyy-MM-dd" value-format="yyyy-MM-dd" :clearable='!islimitlength'>
    </el-date-picker>
  </div>
</template>

<script>
  import {
    getDateTime,
    getDateStr,
    longQueryTime
  } from '@/utils/tools'

  export default {
    name: 'dateRange1',
    props: {
      longtime: { //时间限制长度 的时间戳值
        default: longQueryTime(1,'month'),
        type: Number
      },
      islimitlength: { //是否开启时间限制 true限制,false不限制
        type: Boolean,
        default: false
      },
      pickerEndOptions: {
        default: () => {},
        type: Object
      },
      defaultTime: {
        default: () => [],
        type: Array
      },
      // 是否增加时间后缀，起始(00:00:00)终止(23:59:59)
      isAutoAddTime: {
        type: Boolean,
        default: false
      },
      islimitText: { //时间限制得大小
        default: '1个月',
        type: String
      },
      // 结束时间偏离今天的毫秒数
      endTimeOffset:{
        type:Number,
        default:0
      }
    },
    model:{
      prop:"defaultTime",
      event:"change"
    },
    data() {
      var vm = this;
      return {
        optionsEnd: {
          disabledDate: (time) => {
            // 今天完结之前+对应的偏移
            // let today = new Date();
            // today.setHours(23, 59, 59, 59);
            let start = vm.startTime?new Date(vm.startTime.replace(/-/g, "/")).getTime():'';
            let end=Date.now()+vm.endTimeOffset*1000
            if(start){
              return time.getTime() > end || time.getTime()<start;
            }else{
              return time.getTime() > end;
            }
          }
        },
        startTime: '',
        endTime: '',
        initLongTime:longQueryTime(1,'month'),
        optionsStart:{
          disabledDate: (time) => {
            let end = vm.endTime?new Date(vm.endTime.replace(/-/g, "/")).getTime():'';
            if (vm.islimitlength) {
              return time.getTime() < (end - vm.longtime) || time.getTime() > end
            }else if(end){
              return time.getTime() > end
            }else{
              return time.getTime() > Date.now()
            }
          }
        },
      }
    },
    computed: {},
    watch: {
      defaultTime(val, oldVal) {
        this.startTime = this.setData(val[0]);
        this.endTime = this.setData(val[1]);
      }
    },
    mounted() {
      this.startTime = this.setData(this.defaultTime[0]);
      this.endTime = this.setData(this.defaultTime[1]);
      this.optionsEnd = this.pickerEndOptions? this.pickerEndOptions :this.optionsEnd;
    },
    beforeDestroy() {

    },
    methods: {
      changeStartTime(val) {
        // if(!val&&this.islimitlength) val=this.setData(this.defaultTime[0])
        // this.startTime = val;
        // if (val && this.endTime) {
        //   let start = new Date(val.replace(/-/g, "/")+' 00:00:00').getTime();
        //   let end = new Date(this.endTime.replace(/-/g, "/")+' 23:59:59').getTime();
        //   if (end <= start) {
        //     this.$notify.closeAll();
        //     this.$notify.info({
        //       title: '提示',
        //       message: '开始时间不能大于结束时间'
        //     });
        //     this.startTime = null;
        //   }
        //   let num=end - start;
        //   if (this.islimitlength && (num > this.longtime || num<0)) {
        //     // this.startTime = getDateStr((end - this.longtime), 'date');
        //      this.startTime = this.setData(this.defaultTime[0])
        //   }
        // }
        this.$emit("change-time", this.createValue());
      },
      changeEndTime(val) {
        // if(!val&&this.islimitlength) val=this.setData(this.defaultTime[1])
        // this.endTime = val;
        // if (val && this.startTime) {
        //   let start = new Date(this.startTime.replace(/-/g, "/")+' 00:00:00').getTime();
        //   let end = new Date(val.replace(/-/g, "/")+' 23:59:59').getTime();
        //   if (end <= start) {
        //     this.$notify.closeAll();
        //     this.$notify.info({
        //       title: '提示',
        //       message: '结束时间不能小于开始时间'
        //     });
        //     this.endTime = null;
        //   }
        //   let num= end - start;
        //   if (this.islimitlength && (num > this.longtime || num<0)) {
        //     // this.endTime = getDateStr((start + this.longtime), 'date');
        //     this.endTime = this.setData(this.defaultTime[1])
        //   }
        // }
        this.$emit("change-time", this.createValue());
      },
      createValue(value) {
        value = value ? value : [this.startTime, this.endTime]
        let res = []
        res[0] = this.isAutoAddTime && value[0]? value[0] + " 00:00:00":value[0];
        res[1] = this.isAutoAddTime && value[1]? value[1]+ " 23:59:59":value[1];
        return res;
      },
      setData(val){
        let str=''
        if(val){
          str= getDateStr(new Date(val.replace(/-/g, "/")).getTime(),'date');
        }
        return str;
      }
    }
  }
</script>

<style lang="scss" scoped>
  .time-box {
    .el-date-editor.el-input {
      width: 109px;

      ::v-deep .el-input__inner {
        padding-left: 3px;
      }

      ::v-deep .el-input__prefix {
        display: none;
      }
    }
  }
</style>
