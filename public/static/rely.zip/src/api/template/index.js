export function listRequest() {
  return Promise.resolve({
    resultCode: '0000',
    data: {}
  })
}
export function detailRequest() {
  return Promise.resolve({
    resultCode: '0000',
    data: {}
  })
}
export function editRequest() {
  return Promise.resolve({
    resultCode: '0000',
    data: {}
  })
}
export function addRequest() {
  return Promise.resolve({
    resultCode: '0000',
    data: {}
  })
}

