/**
 * 去除json对象里面的空值
 * @param {*} data
 * @returns data
 */
export function deleteNull(data) {
  Object.keys(data).forEach((item) => {
    // 两个== 不是=== null          ===不是== ''
    if (data[item] == null || data[item] === '') {
      delete data[item]
    }
  })
  return data
}

/**
 * 时间戳转时间
 * @param {Array,value,key}, arr 传入的数组  key=id 比较的Key值   value：item[key]==value
 * @return {null||Object}  没找到，或者传入的非数组，返回null
 */

export function find(array = [], value = null, key = 'id') {
  if (Object.prototype.toString.call(array) == '[object Array]') {
    return array.find((item) => {
      return item[key] == value
    }) || {}
  }
  return {}
}
