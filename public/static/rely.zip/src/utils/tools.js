/**
 * @param {Number} timeStamp 传入的时间差
 * @param {Number} startType 要返回的时间
 * 获取30天之前
 */
export const getDateTime = (number, startType) => {
  number = number || 0
  const today = new Date()
  if (number) today.setHours(23, 59, 59)
  const nowTime = today.getTime() - number
  const time = getDate(nowTime, startType || 'year')
  return time
}

/**
 * @param {Number} num 数值
 * @returns {String} 处理后的字符串
 * @description 如果传入的数值小于10，即位数只有1位，则在前面补充0
 */
const getHandledValue = num => {
  return num < 10 ? '0' + num : num
}

/**
 * @param {Number} timeStamp 传入的时间戳
 * @param {Number} startType 要返回的时间字符串的格式类型，传入'year'则返回年开头的完整时间，date 只要年月日
 */
const getDate = (timeStamp, startType) => {
  let d = ''
  if ((timeStamp + '').length > 10) d = new Date(timeStamp)
  else d = new Date(timeStamp * 1000)
  const year = d.getFullYear()
  const month = getHandledValue(d.getMonth() + 1)
  const date = getHandledValue(d.getDate())
  const hours = getHandledValue(d.getHours())
  const minutes = getHandledValue(d.getMinutes())
  const second = getHandledValue(d.getSeconds())
  let resStr = ''
  if (startType === 'year') resStr = year + '-' + month + '-' + date + ' ' + hours + ':' + minutes + ':' + second
  else resStr = year + '-' + month + '-' + date
  return resStr
}

/**
 * 获取数组中 渲染到列表中的最大宽度
 *
 */
export const getStrWidth = (arr, minwidth) => {
  const arrLen = []
  const min = minwidth || 80
  for (let i = 0; i < arr.length; i++) {
    const str = arr[i]
    if (str) {
      const char = str.match(/[\u2E80-\u9FFF]/g) // 中文
      const charLen = char ? char.length : 0
      const num = str.match(/\d|\./g) // 数字
      const numLen = num ? num.length : 0
      const otherLen = str.length - charLen - numLen // 其它
      const width = Math.ceil(charLen * 1.1 + numLen * 0.65 + otherLen * 0.5) * 17
      arrLen.push(width)
    }
  }
  const maxWidth = arrLen.length > 0 ? Math.max(...arrLen) : 0
  return maxWidth > min ? (maxWidth > 400 ? 400 : maxWidth) : minwidth
}

// 生成批量设置表格列宽监听函数
export const createColumnWidthWatchFn = (tableWidth, isTree = false, childKey = 'children') => {
  const width = JSON.parse(JSON.stringify(tableWidth))
  return function(val) {
    function expandTree(val) {
      const res = []
      let arr = JSON.parse(JSON.stringify(val))
      while (arr.length > 0) {
        const item = arr.pop()
        res.push(item)
        if (item && Array.isArray(item[childKey])) {
          arr = arr.concat(item[childKey])
        }
      }
      return res
    }
    const temp = {}
    for (const key in width) {
      temp[key] = []
    }
    const list = isTree ? expandTree(val) : val
    list.forEach(v => {
      for (const key in temp) {
        temp[key].push(String(v[key]))
      }
    })
    for (const key in temp) {
      tableWidth[key] = getStrWidth(temp[key], width[key])
    }
  }
}

/**
 * @param {Array} arr1
 * @param {Array} arr2
 * @description 得到两个数组的交集, 两个数组的元素为数值或字符串
 */
export const getIntersection = (arr1, arr2) => {
  const len = Math.min(arr1.length, arr2.length)
  let i = -1
  const res = []
  while (++i < len) {
    const item = arr2[i]
    if (arr1.indexOf(item) > -1) res.push(item)
  }
  return res
}

/**
 * @param {Array} arr1
 * @param {Array} arr2
 * @description 得到两个数组的并集, 两个数组的元素为数值或字符串
 */
export const getUnion = (arr1, arr2) => {
  return Array.from(new Set([...arr1, ...arr2]))
}

/**
 * @param {Array} target 目标数组
 * @param {Array} arr 需要查询的数组
 * @description 判断要查询的数组是否至少有一个元素包含在目标数组中
 */
export const hasOneOf = (targetarr, arr) => {
  return targetarr.some(_ => arr.indexOf(_) > -1)
}

/**
 * @param {String|Number} value 要验证的字符串或数值
 * @param {*} validList 用来验证的列表
 */
export function oneOf(value, validList) {
  for (let i = 0; i < validList.length; i++) {
    if (value === validList[i]) {
      return true
    }
  }
  return false
}

/**
 * @param {Number} timeStamp 判断时间戳格式是否是毫秒
 * @returns {Boolean}
 */
const isMillisecond = timeStamp => {
  const timeStr = String(timeStamp)
  return timeStr.length > 10
}

/**
 * @param {Number} timeStamp 传入的时间戳
 * @param {Number} currentTime 当前时间时间戳
 * @returns {Boolean} 传入的时间戳是否早于当前时间戳
 */
const isEarly = (timeStamp, currentTime) => {
  return timeStamp < currentTime
}

/**
 * @description 获取当前时间（年月日）
 */
export const getDateNow = () => {
  const date = new Date()
  const year = date.getFullYear()
  let month = date.getMonth() + 1
  let day = date.getDate()
  if (month >= 1 && month <= 9) {
    month = `0${month}`
  }
  if (day >= 0 && day <= 9) {
    day = `0${day}`
  }
  const currentdate = `${year}-${month}-${day}`
  return currentdate
}

export const getDateStr = getDate

/**
 * @param {String|Number} timeStamp 时间戳
 * @returns {String} 相对时间字符串
 */
export const getRelativeTime = timeStamp => {
  // 判断当前传入的时间戳是秒格式还是毫秒
  const IS_MILLISECOND = isMillisecond(timeStamp)
  // 如果是毫秒格式则转为秒格式
  if (IS_MILLISECOND) Math.floor(timeStamp /= 1000)
  // 传入的时间戳可以是数值或字符串类型，这里统一转为数值类型
  timeStamp = Number(timeStamp)
  // 获取当前时间时间戳
  const currentTime = Math.floor(Date.parse(new Date()) / 1000)
  // 判断传入时间戳是否早于当前时间戳
  const IS_EARLY = isEarly(timeStamp, currentTime)
  // 获取两个时间戳差值
  let diff = currentTime - timeStamp
  // 如果IS_EARLY为false则差值取反
  if (!IS_EARLY) diff = -diff
  let resStr = ''
  const dirStr = IS_EARLY ? '前' : '后'
  // 少于等于59秒
  if (diff <= 59) resStr = diff + '秒' + dirStr
  // 多于59秒，少于等于59分钟59秒
  else if (diff > 59 && diff <= 3599) resStr = Math.floor(diff / 60) + '分钟' + dirStr
  // 多于59分钟59秒，少于等于23小时59分钟59秒
  else if (diff > 3599 && diff <= 86399) resStr = Math.floor(diff / 3600) + '小时' + dirStr
  // 多于23小时59分钟59秒，少于等于29天59分钟59秒
  else if (diff > 86399 && diff <= 2623859) resStr = Math.floor(diff / 86400) + '天' + dirStr
  // 多于29天59分钟59秒，少于364天23小时59分钟59秒，且传入的时间戳早于当前
  else if (diff > 2623859 && diff <= 31567859 && IS_EARLY) resStr = getDate(timeStamp)
  else resStr = getDate(timeStamp, 'year')
  return resStr
}

/**
 * @returns {String} 当前浏览器名称
 */
export const getExplorer = () => {
  const ua = window.navigator.userAgent
  const isExplorer = (exp) => {
    return ua.indexOf(exp) > -1
  }
  if (isExplorer('MSIE')) return 'IE'
  else if (isExplorer('Firefox')) return 'Firefox'
  else if (isExplorer('Chrome')) return 'Chrome'
  else if (isExplorer('Opera')) return 'Opera'
  else if (isExplorer('Safari')) return 'Safari'
}

/**
 * @description 绑定事件 on(element, event, handler)
 */
export const on = (function() {
  if (document.addEventListener) {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.addEventListener(event, handler, false)
      }
    }
  } else {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.attachEvent('on' + event, handler)
      }
    }
  }
})()

/**
 * @description 解绑事件 off(element, event, handler)
 */
export const off = (function() {
  if (document.removeEventListener) {
    return function(element, event, handler) {
      if (element && event) {
        element.removeEventListener(event, handler, false)
      }
    }
  } else {
    return function(element, event, handler) {
      if (element && event) {
        element.detachEvent('on' + event, handler)
      }
    }
  }
})()

/**
 * 判断一个对象是否存在key，如果传入第二个参数key，则是判断这个obj对象是否存在key这个属性
 * 如果没有传入key这个参数，则判断obj对象是否有键值对
 */
export const hasKey = (obj, key) => {
  if (key) return key in obj
  else {
    const keysArr = Object.keys(obj)
    return keysArr.length
  }
}

/**
 * @param {*} obj1 对象
 * @param {*} obj2 对象
 * @description 判断两个对象是否相等，这两个对象的值只能是数字或字符串
 */
export const objEqual = (obj1, obj2) => {
  const keysArr1 = Object.keys(obj1)
  const keysArr2 = Object.keys(obj2)
  if (keysArr1.length !== keysArr2.length) return false
  else if (keysArr1.length === 0 && keysArr2.length === 0) return true
  /* eslint-disable-next-line */
  else return !keysArr1.some(key => obj1[key] != obj2[key])
}

/**
 * @param {*} str 传入的字符串
 * @description 去除字符串html标签
 */
export const delHtmlTag = str => str.replace(/<[^>]+>/g, '')

/**
 * 最大查询范围时间
 *30天：1000*60 *60 *24*30=2,592,000,000
 * type:单位  year：年;month 月，data:日
 */
export const longQueryTime = (num, type) => {
  num = num || 30
  type = type || 'date'
  let time
  if (type === 'date') time = 1000 * 60 * 60 * 24 * num
  else {
    const endTime = new Date().setHours(23, 59, 59)
    const today = new Date().setHours(0, 0, 0)
    let d = ''
    if ((today + '').length > 10) d = new Date(today)
    else d = new Date(today * 1000)
    let year = (type == 'year' ? d.getFullYear() - num : d.getFullYear())
    let monthNumber = d.getMonth() + 1
    if (type == 'month') {
      if (monthNumber <= num) {
        year = year - Math.floor(num / 12)
        if (num % 12 != 0) {
          const num2 = num - (Math.floor(num / 12) * 12)
          if (num2 >= monthNumber)year--
          monthNumber = 12 - Math.abs(num2 - monthNumber)
        }
      } else {
        monthNumber = monthNumber - num
      }
    }
    const month = getHandledValue(monthNumber)
    const date = getHandledValue(d.getDate())
    const hours = getHandledValue(d.getHours())
    const minutes = getHandledValue(d.getMinutes())
    const second = getHandledValue(d.getSeconds())
    const resStr = year + '/' + month + '/' + date + ' ' + hours + ':' + minutes + ':' + second
    time = endTime - new Date(resStr).getTime()
  }
  return time
}

/**
 * 将一个函数转为具有防抖功能的函数
 * @param {*} func 待转换的函数
 * @param {*} wait  延迟时间(毫秒)
 * @param {*} immediate 是否立即执行
 */
export const debounce = (func, wait, immediate) => {
  let timeout
  return function() {
    const ctx = this
    const args = arguments
    if (timeout) clearTimeout(timeout)
    if (immediate) {
      const callNow = !timeout
      timeout = setTimeout(() => {
        timeout = null
      }, wait)
      if (callNow) func.apply(ctx, args)
    } else {
      timeout = setTimeout(function() {
        func.apply(ctx, args)
      }, wait)
    }
  }
}

export const showXml = (str) => {
  var text = str

  // 去掉多余的空格
  text = '\n' + text.replace(/(<\w+)(\s.*?>)/g, function($0, name, props) {
    return name + ' ' + props.replace(/\s+(\w+=)/g, ' $1')
  }).replace(/>\s*?</g, '>\n<')

  // 把注释编码
  text = text.replace(/\n/g, '\r').replace(/<!--(.+?)-->/g, function($0, text) {
    var ret = '<!--' + escape(text) + '-->'
    return ret
  }).replace(/\r/g, '\n')

  // 调整格式
  var rgx = /\n(<(([^\?]).+?)(?:\s|\s*?>|\s*?(\/)>)(?:.*?(?:(?:(\/)>)|(?:<(\/)\2>)))?)/mg
  var nodeStack = []
  var output = text.replace(rgx, function($0, all, name, isBegin, isCloseFull1, isCloseFull2, isFull1, isFull2) {
    var isClosed = (isCloseFull1 == '/') || (isCloseFull2 == '/') || (isFull1 == '/') || (isFull2 == '/')
    var prefix = ''
    if (isBegin == '!') {
      prefix = getPrefix(nodeStack.length)
    } else {
      if (isBegin != '/') {
        prefix = getPrefix(nodeStack.length)
        if (!isClosed) {
          nodeStack.push(name)
        }
      } else {
        nodeStack.pop()
        prefix = getPrefix(nodeStack.length)
      }
    }
    var ret = '\n' + prefix + all
    return ret
  })

  var prefixSpace = -1
  var outputText = output.substring(1)

  // 把注释还原并解码，调格式
  outputText = outputText.replace(/\n/g, '\r').replace(/(\s*)<!--(.+?)-->/g, function($0, prefix, text) {
    if (prefix.charAt(0) == '\r') { prefix = prefix.substring(1) }
    text = unescape(text).replace(/\r/g, '\n')
    var ret = '\n' + prefix + '<!--' + text.replace(/^\s*/mg, prefix) + '-->'
    return ret
  })
  // alert(outputText);

  outputText =	outputText.replace(/\s+$/g, '').replace(/\r/g, '\r\n')

  return outputText
}

function getPrefix(prefixIndex) {
  var span = '    '
  var output = []
  for (var i = 0; i < prefixIndex; ++i) {
    output.push(span)
  }

  return output.join('')
}

// 删除json对象中的空值属性
export function deEm(obj) {
  for (const i in obj) {
    (!i || !obj[i]) && (delete obj[i])
  }
  return obj
}
