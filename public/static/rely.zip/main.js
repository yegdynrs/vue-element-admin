`
import Vue from 'vue'
import ElementUI from 'element-ui'
import VueClipboard from 'vue-clipboard2'
Vue.use(ElementUI)
// 复制
Vue.use(VueClipboard)
// 引入全局组件
import Dialog from '@/components/dialog'
Vue.use(Dialog)
import utils from '@/lib/utils.js'
Vue.prototype.$utils = utils
`
